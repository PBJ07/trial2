﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Control_Arrays_Practice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //GLOBAL array of buttons and labels
        Button[] myButtons; 
        Label[] Labels;
        private void Form1_Load(object sender, EventArgs e)
        {
            //Put buttons from your form into the array
            myButtons = new Button[] { button1, button2, button3, button4, button5, button6 };
            Labels = new Label[] { label1, label2, label3, label4 };

            //What to display on all buttons
            //Code to happen when the buttons are clicked
            for (int n = 0; n < myButtons.Count(); n++)
            {
                myButtons[n].Text = "";
                myButtons[n].Click += new EventHandler(myButtons_Click);
            }

            //What to display on all labels
            //Code to happen when the labels are clicked
            for (int l = 0; l < Labels.Count(); l++)
            {
                Labels[l].Text = "Click Me";
                Labels[l].Click += new EventHandler(Labels_Click);
            }
        }
        
        private void myButtons_Click(object sender, EventArgs e)
        {
            //Add '*' to buttons
            Button currentButton = (Button)sender;
            currentButton.Text += "*";
        }

        private void Labels_Click(object sender, EventArgs e)
        {
            //Add TxtEnterWord input into the selected labels
            Label currentLabel = (Label)sender;
            currentLabel.Text = txtEnterWord.Text;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //Clear '*' in buttons
            for (int i = 0; i < myButtons.Count(); i++)
            {
                myButtons[i].Text = "";
            }
        }

        private void btnLetters_Click(object sender, EventArgs e)
        {
            //Count the number of letters on the labels
            int totalLetters = 0;
            for (int length = 0; length < Labels.Count(); length++)
            {
                totalLetters += Labels[length].Text.Length;
            }
            MessageBox.Show($"Total number of letters is {totalLetters}"); //Show how many letters
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Exit Program
            Application.Exit();
        }
    }
}
